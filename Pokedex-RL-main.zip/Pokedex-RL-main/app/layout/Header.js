export default () => 
<header id="header">
  <div className="header-left" />
  <div className="header-right right-0" />
</header>
